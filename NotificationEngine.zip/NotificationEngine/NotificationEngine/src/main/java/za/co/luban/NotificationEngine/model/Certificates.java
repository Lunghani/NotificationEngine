package za.co.luban.NotificationEngine.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@Entity
@Table(name = "certificates")
public class Certificates {

    @Id @GeneratedValue
    Long id;
    Long employeeId;
    String employeeName;
    String certificateId;
    String certificateName;
    String certificateType;
    String certificateNumber;
    String expirationDate;
    String issuedDate;

}

